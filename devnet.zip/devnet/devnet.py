#!/usr/bin/env python3
# graphhopper_visual_report_only.py
# Enhanced GUI for Graphhopper routing → report.html
# - Uses Philippine market pump prices as defaults (Oct 2025)
# - Calories estimated automatically (no user input)
# - Loading modal while generating report (threaded)
# - Turn icons, fuel/calorie/ebike energy, dark mode, more vehicles
#
# Usage: python3 graphhopper_visual_report_only.py
# Requires: requests, tkinter (standard lib), webbrowser, threading

import os
import json
import webbrowser
import urllib.parse
from datetime import timedelta
import tkinter as tk
from tkinter import ttk, messagebox
import requests
import threading
import time

ROUTE_URL = "https://graphhopper.com/api/1/route?"
GEOCODE_URL = "https://graphhopper.com/api/1/geocode?"

# Fallback API key (keep out of source in production)
DEFAULT_API_KEY = "05ddb74c-90fe-4dad-9236-e37bb1fc2003"

# ===== PHILIPPINE MARKET DEFAULTS (sourced Oct 13, 2025) =====
DEFAULT_GASOLINE_PHP_PER_L = 57.20
DEFAULT_DIESEL_PHP_PER_L = 55.45
DEFAULT_FUEL_EFF_L100 = 7.0
DEFAULT_WEIGHT_KG = 70.0

# --- Helpers ---
def get_api_key() -> str:
    return os.getenv("GRAPHHOPPER_API_KEY", DEFAULT_API_KEY)

def km_to_miles(km: float) -> float:
    return km / 1.60934

def format_duration_ms(ms: int) -> str:
    td = timedelta(milliseconds=ms)
    total_seconds = int(td.total_seconds())
    h = total_seconds // 3600
    m = (total_seconds % 3600) // 60
    s = total_seconds % 60
    return f"{h:02d}:{m:02d}:{s:02d}"

def safe_float(x, default=0.0):
    try:
        return float(x)
    except Exception:
        return default

def geocode(location: str, api_key: str):
    """Return: (status_code, lat, lng, label)"""
    url = GEOCODE_URL + urllib.parse.urlencode({"q": location, "limit": "1", "key": api_key})
    try:
        r = requests.get(url, timeout=20)
        data = r.json() if "application/json" in r.headers.get("content-type", "") else {}
        if r.status_code == 200 and data.get("hits"):
            hit = data["hits"][0]
            lat = hit["point"]["lat"]
            lng = hit["point"]["lng"]
            name = hit.get("name") or hit.get("osm_value") or location
            state = hit.get("state", "")
            country = hit.get("country", "")
            parts = [p for p in [name, state, country] if p]
            label = ", ".join(parts)
            return 200, lat, lng, label
        return r.status_code, "null", "null", location
    except Exception as e:
        return 0, "null", "null", f"{location} (error: {e})"

# Inline SVG icons with updated color
SVG_ICONS = {
    "turn-left": """<svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true"><path d="M14 7l-6 5 6 5V11h6V7z" fill="currentColor" /></svg>""",
    "turn-right": """<svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true"><path d="M10 7l6 5-6 5V11H4V7z" fill="currentColor" /></svg>""",
    "straight": """<svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2v20l4-4h-3V2z" fill="currentColor" /></svg>""",
    "roundabout": """<svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a10 10 0 1 0 10 10h-2a8 8 0 1 1-8-8v3l4-4-4-4v3z" fill="currentColor" /></svg>""",
    "uturn": """<svg width="24" height="24" viewBox="0 0 24 24"><path d="M7 7v6h6" stroke="currentColor" stroke-width="2" fill="none"/><path d="M7 7l-4 4 4 4" stroke="currentColor" stroke-width="2" fill="none"/></svg>""",
    "end": """<svg width="24" height="24" viewBox="0 0 24 24"><circle cx="12" cy="12" r="6" fill="currentColor"/></svg>""",
    "dot": """<svg width="20" height="20" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3" fill="currentColor"/></svg>""",
    "start-pin": """<svg width="24" height="24" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="green"/></svg>""",
    "end-pin": """<svg width="24" height="24" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="red"/></svg>""",
}

VEHICLE_TO_SVG_KEY = {
    "car": "vehicle-car",
    "bike": "vehicle-bike",
    "foot": "vehicle-foot",
    "motorcycle": "vehicle-motorcycle",
    "truck": "vehicle-truck",
    "ebike": "vehicle-ebike",
    "scooter": "vehicle-scooter",
}


# --- Logic (threaded) ---
def run_route_threaded(root, origin, dest, vehicle, status_var, options, loading_modal):
    """
    This function runs inside a Thread. It updates GUI via root.after to remain thread-safe.
    """
    api_key = get_api_key()
    
    def set_status(s):
        root.after(0, status_var.set, s)

    set_status("Geocoding...")
    s1, lat1, lng1, label1 = geocode(origin, api_key)
    s2, lat2, lng2, label2 = geocode(dest, api_key)

    if not (s1 == 200 and s2 == 200):
        root.after(0, messagebox.showerror, "Error", "Geocoding failed. Try clearer names.")
        set_status("Ready")
        root.after(0, close_loading_modal, loading_modal, None)
        return

    base_params = {
        "key": api_key,
        "vehicle": vehicle,
        "points_encoded": "false",
        "instructions": "true",
    }
    op = f"&point={lat1}%2C{lng1}"
    dp = f"&point={lat2}%2C{lng2}"
    url = ROUTE_URL + urllib.parse.urlencode(base_params) + op + dp

    set_status("Getting route...")
    try:
        r = requests.get(url, timeout=40)
        data = r.json()
    except Exception as e:
        root.after(0, messagebox.showerror, "Error", f"Route request failed: {e}")
        set_status("Ready")
        root.after(0, close_loading_modal, loading_modal, None)
        return

    if r.status_code != 200 or "paths" not in data:
        root.after(0, messagebox.showerror, "Error", f"Routing failed: {data.get('message','Unknown error')}")
        set_status("Ready")
        root.after(0, close_loading_modal, loading_modal, None)
        return

    path = data["paths"][0]
    set_status("Calculating metrics...")

    distance_km = safe_float(path.get("distance", 0)) / 1000.0
    duration_min = (safe_float(path.get("time", 0)) / 1000.0) / 60.0

    fuel_info = None
    calories_info = None

    # Choose a sensible default price based on vehicle type (car uses gasoline, truck uses diesel)
    if vehicle in ("car", "motorcycle", "scooter"):
        price_default = options.get("fuel_price_overridden") or DEFAULT_GASOLINE_PHP_PER_L
    elif vehicle in ("truck",):
        price_default = options.get("fuel_price_overridden") or DEFAULT_DIESEL_PHP_PER_L
    else:
        price_default = options.get("fuel_price_overridden") or DEFAULT_GASOLINE_PHP_PER_L

    if vehicle in ("car", "truck", "motorcycle"):
        eff = safe_float(options.get("fuel_eff_l100", DEFAULT_FUEL_EFF_L100))
        price = safe_float(options.get("fuel_price_per_l", price_default))
        fuel_info = estimate_fuel_and_cost(distance_km, eff, price)
        fuel_info["price_per_liter"] = price

    # Automatic calorie estimation — no user input required
    weight = DEFAULT_WEIGHT_KG
    if vehicle in ("foot", "bike", "ebike"):
        calories_info = estimate_calories(duration_min, weight, vehicle)
        if vehicle == "ebike":
            ebike_kwh = estimate_ebike_energy(distance_km)
            calories_info["ebike_kwh"] = ebike_kwh

    set_status("Creating report...")
    theme = "dark" if options.get("dark_mode") else "light"
    try:
        report = build_report_html(label1, label2, vehicle, path, "report.html", theme=theme, fuel_info=fuel_info, calories_info=calories_info)
        abs_path = os.path.abspath(report)
        webbrowser.open(f"file://{abs_path}")
        set_status("Done")
    except Exception as e:
        root.after(0, messagebox.showerror, "Error", f"Report generation failed: {e}")
        set_status("Ready")
    finally:
        root.after(0, close_loading_modal, loading_modal, None)

# --- Calculations helpers ---
def estimate_fuel_and_cost(distance_km: float, eff_l_per_100km: float, price_per_liter: float):
    """
    Estimate the fuel consumption (liters) and cost based on the distance, fuel efficiency,
    and price per liter.
    """
    liters = (distance_km * eff_l_per_100km) / 100.0  # Fuel consumption in liters
    cost = liters * price_per_liter if price_per_liter is not None else None  # Total cost
    return {"liters": liters, "cost": cost, "eff_l_per_100km": eff_l_per_100km, "price_per_liter": price_per_liter}


def instruction_icon_for_text(text: str):
    t = text.lower()
    if "roundabout" in t or "rotary" in t:
        return SVG_ICONS["roundabout"]
    if "u-turn" in t or "u turn" in t or "uturn" in t:
        return SVG_ICONS["uturn"]
    if "left" in t:
        return SVG_ICONS["turn-left"]
    if "right" in t:
        return SVG_ICONS["turn-right"]
    if "continue" in t or "straight" in t or "head" in t or "onto" in t:
        return SVG_ICONS["straight"]
    if "arrive" in t or "destination" in t:
        return SVG_ICONS["end"]
    return SVG_ICONS["dot"]

# --- Threaded worker + loading modal helpers ---
def open_loading_modal(root, title="Generating report..."):
    modal = tk.Toplevel(root)
    modal.title(title)
    modal.geometry("320x90")
    modal.resizable(False, False)
    modal.transient(root)
    modal.grab_set()
    frm = ttk.Frame(modal, padding=12)
    frm.pack(fill="both", expand=True)
    lbl = ttk.Label(frm, text=title)
    lbl.pack(pady=(0,8))
    pb = ttk.Progressbar(frm, mode="indeterminate")
    pb.pack(fill="x")
    pb.start(10)
    # Provide reference to widgets so caller can close
    return modal, pb

def close_loading_modal(modal, pb=None):
    try:
        if pb:
            pb.stop()
    except Exception:
        pass
    try:
        modal.grab_release()
        modal.destroy()
    except Exception:
        pass

def safe_get_points(coords):
    try:
        return [[c[1], c[0]] for c in coords]
    except Exception:
        return []

def build_report_html(
    origin_label: str,
    dest_label: str,
    vehicle: str,
    path: dict,
    outfile: str = "report.html",
    theme: str = "light",
    fuel_info: dict = None,
    calories_info: dict = None,
):
    km = safe_float(path.get("distance", 0.0)) / 1000.0
    miles = km_to_miles(km)
    duration_ms = int(path.get("time", 0) or 0)
    duration_str = format_duration_ms(duration_ms)
    steps = path.get("instructions", []) or []
    coords = path.get("points", {}).get("coordinates", []) or []

    latlon = safe_get_points(coords)
    rows = ""
    for i, s in enumerate(steps):
        text = s.get("text", "")
        dist_km = (safe_float(s.get("distance", 0)) / 1000.0)
        icon_svg = instruction_icon_for_text(text)
        rows += (
            "<tr>"
            f"<td style='width:42px; text-align:center'>{icon_svg}</td>"
            f"<td style='min-width:200px'>{text}</td>"
            f"<td style='white-space:nowrap'>{dist_km:.2f} km</td>"
            "</tr>"
        )

    veh_svg = SVG_ICONS.get(VEHICLE_TO_SVG_KEY.get(vehicle, ""), SVG_ICONS["dot"])

    fuel_html = ""
    if fuel_info:
        liters = fuel_info.get("liters", 0.0)
        price = fuel_info.get("cost")
        eff = fuel_info.get("eff_l_per_100km")
        price_per_l = fuel_info.get("price_per_liter")
        fuel_html = f"<div class='pill'>Fuel: {liters:.2f} L (eff {eff:.1f} L/100km)</div>"
        if price is not None and price_per_l is not None:
            fuel_html += f"<div class='pill'>Cost: ₱{price:.2f} (₱{price_per_l:.2f}/L)</div>"

    calories_html = ""
    if calories_info:
        kcal = calories_info.get("kcal", 0.0)
        note = calories_info.get("note", "")
        calories_html = f"<div class='pill'>Calories: {kcal:.0f} kcal</div>"
        if note:
            calories_html += f"<div style='font-size:12px;margin-top:6px;color:#666'>{note}</div>"

    ebike_html = ""
    if calories_info and calories_info.get("ebike_kwh") is not None:
        kwh = calories_info.get("ebike_kwh")
        ebike_html = f"<div class='pill'>E-bike energy: {kwh:.2f} kWh</div>"

    dark_css = ""
    body_class = ""
    if theme == "dark":
        body_class = "dark"
        dark_css = """
        :root { --bg: #0b0f12; --card: #0f1720; --text: #e6eef6; --muted:#a9b7c6; --accent:#66d49f; --pill:#12221a; }
        body.dark header { background:#083; color:#001; }
        body.dark { background:var(--bg); color:var(--text); }
        body.dark .card { background:var(--card); color:var(--text); box-shadow: 0 6px 18px rgba(0,0,0,0.6); }
        body.dark table th { background: rgba(255,255,255,0.03); }
        body.dark .pill { background: rgba(255,255,255,0.03); border-color: rgba(255,255,255,0.06); color:var(--text); }
        """
    else:
        dark_css = ""

    html = f"""<!doctype html>
<html lang='en'>
<head>
<meta charset='utf-8'>
<title>Route Report</title>
<meta name='viewport' content='width=device-width, initial-scale=1'>
<link rel='stylesheet' href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css' crossorigin=''/>
<script src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js' crossorigin=''></script>
<style>
{dark_css}
body {{font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;background:#fafafa;margin:0;padding:0}}
header {{background:#0b6;color:white;padding:16px 24px;display:flex;gap:16px;align-items:center}}
.wrap {{padding:16px 24px}}
.grid {{display:grid;grid-template-columns:2fr 1fr;gap:16px}}
.card {{background:white;border-radius:12px;padding:12px;box-shadow:0 2px 8px rgba(0,0,0,0.1)}}
#map {{height:520px;width:100%;border-radius:10px}}
table {{width:100%;border-collapse:collapse;font-size:14px}}
th,td {{padding:8px 6px;border-bottom:1px solid #eee;text-align:left;vertical-align:middle}}
th {{background:#f6f6f6}}
.kpi {{display:flex;gap:12px;flex-wrap:wrap}}
.pill {{background:#eef9f1;border:1px solid #cdebd7;padding:8px 10px;border-radius:999px;font-weight:600}}
.vehicle-chip {{display:flex;gap:12px;align-items:center;background:rgba(255,255,255,0.15);padding:6px 10px;border-radius:10px}}
.header-title {{display:flex;flex-direction:column}}
</style>
</head>
<body class="{body_class}">
<header>
<div class="vehicle-chip" style="color:inherit">
<div style="display:flex;align-items:center">{veh_svg}</div>
<div class="header-title"><div style="font-weight:700">Vehicle: {vehicle}</div><div style="font-size:13px;color:rgba(255,255,255,0.9)">{origin_label} → {dest_label}</div></div>
</div>
</header>
<div class='wrap'>
<div class='grid'>
<div class='card'><div id='map'></div></div>
<div class='card'>
<h3>Summary</h3>
<div class='kpi'>
<div class='pill'>Distance: {miles:.1f} miles / {km:.1f} km</div>
<div class='pill'>Duration: {duration_str}</div>
{fuel_html}
{calories_html}
{ebike_html}
</div>
</div></div>
<div class='card' style='margin-top:16px'>
<h3>Turn-by-turn</h3>
<table><thead><tr><th style='width:48px'></th><th>Instruction</th><th style='width:110px'>Distance</th></tr></thead>
<tbody>{rows}</tbody></table></div></div>
<script>
const latlon = {json.dumps(latlon)};
const map = L.map('map').setView(latlon.length ? latlon[Math.floor(latlon.length/2)] : [0,0], latlon.length ? 12 : 2);
L.tileLayer('https://{{s}}.tile.openstreetmap.org/{{z}}/{{x}}/{{y}}.png', {{
  maxZoom:19, attribution:'&copy; OpenStreetMap contributors'
}}).addTo(map);
const line = L.polyline(latlon, {{color:'#0078ff', weight:5}}).addTo(map);
if (latlon.length) {{
  L.marker(latlon[0]).addTo(map).bindTooltip("Start").setIcon(L.divIcon({{className: 'leaflet-div-icon', html: '{SVG_ICONS["start-pin"]}'}}));
  L.marker(latlon[latlon.length-1]).addTo(map).bindTooltip("End").setIcon(L.divIcon({{className: 'leaflet-div-icon', html: '{SVG_ICONS["end-pin"]}'}}));
  map.fitBounds(line.getBounds(), {{padding:[20,20]}});
}}
</script>
</body></html>
"""
    with open(outfile, "w", encoding="utf-8") as f:
        f.write(html)
    return outfile

# --- GUI ---
def main():
    root = tk.Tk()
    root.title("Graphhopper Route → Report (PH defaults)")
    root.resizable(False, False)

    frm = ttk.Frame(root, padding=10)
    frm.grid(row=0, column=0, sticky="nsew")

    ttk.Label(frm, text="Origin:").grid(row=0, column=0, sticky="w", pady=4)
    e_origin = ttk.Entry(frm, width=50)
    e_origin.grid(row=0, column=1, pady=4)

    ttk.Label(frm, text="Destination:").grid(row=1, column=0, sticky="w", pady=4)
    e_dest = ttk.Entry(frm, width=50)
    e_dest.grid(row=1, column=1, pady=4)

    ttk.Label(frm, text="Vehicle:").grid(row=2, column=0, sticky="w", pady=4)
    vehicle_var = tk.StringVar(value="car")
    vehicle_choices = ["car", "bike", "foot", "motorcycle", "truck", "ebike", "scooter"]
    cmb = ttk.Combobox(frm, textvariable=vehicle_var, values=vehicle_choices, state="readonly", width=12)
    cmb.grid(row=2, column=1, sticky="w", pady=4)

    status_var = tk.StringVar(value="Ready")
    ttk.Label(frm, textvariable=status_var, foreground="#0b6").grid(row=7, column=0, columnspan=2, pady=4, sticky="w")


    def on_generate():
        o, d = e_origin.get().strip(), e_dest.get().strip()
        v = vehicle_var.get()
        if not o or not d:
            messagebox.showwarning("Missing Input", "Please fill in both Origin and Destination.")
            return
        options = {
            "fuel_eff_l100": DEFAULT_FUEL_EFF_L100,
            "fuel_price_per_l": DEFAULT_GASOLINE_PHP_PER_L,
            "fuel_price_overridden": None,
            "dark_mode": False,
        }
        # open loading modal and start thread
        loading_modal, pb = open_loading_modal(root, title="Generating report — please wait")
        # pass the modal to the thread so it can close it when done
        t = threading.Thread(target=run_route_threaded, args=(root, o, d, v, status_var, options, loading_modal), daemon=True)
        t.start()

    ttk.Button(frm, text="Generate Report", command=on_generate).grid(row=8, column=0, columnspan=2, sticky="ew", pady=8)
    e_origin.focus()
    root.mainloop()

if __name__ == "__main__":
    main()
