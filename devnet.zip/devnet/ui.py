#!/usr/bin/env python3
# Simple GUI for Graphhopper routing → report.html
# No API key entry (uses environment variable or default fallback)
# Generates and opens an HTML route report automatically.

import os
import json
import webbrowser
import urllib.parse
from datetime import timedelta
import tkinter as tk
from tkinter import ttk, messagebox
import requests

ROUTE_URL = "https://graphhopper.com/api/1/route?"
GEOCODE_URL = "https://graphhopper.com/api/1/geocode?"

# Set your fallback API key here (or rely on GRAPHHOPPER_API_KEY env)
DEFAULT_API_KEY = "05ddb74c-90fe-4dad-9236-e37bb1fc2003"


# --- Helpers ---
def get_api_key() -> str:
    return os.getenv("GRAPHHOPPER_API_KEY", DEFAULT_API_KEY)


def km_to_miles(km: float) -> float:
    return km / 1.60934


def format_duration_ms(ms: int) -> str:
    td = timedelta(milliseconds=ms)
    total_seconds = int(td.total_seconds())
    h = total_seconds // 3600
    m = (total_seconds % 3600) // 60
    s = total_seconds % 60
    return f"{h:02d}:{m:02d}:{s:02d}"


def geocode(location: str, api_key: str):
    """Return: (status_code, lat, lng, label)"""
    url = GEOCODE_URL + urllib.parse.urlencode({"q": location, "limit": "1", "key": api_key})
    try:
        r = requests.get(url, timeout=20)
        data = r.json() if "application/json" in r.headers.get("content-type", "") else {}
        if r.status_code == 200 and data.get("hits"):
            hit = data["hits"][0]
            lat = hit["point"]["lat"]
            lng = hit["point"]["lng"]
            name = hit.get("name", location)
            state = hit.get("state", "")
            country = hit.get("country", "")
            label = f"{name}, {state}, {country}".strip(", ")
            return 200, lat, lng, label
        return r.status_code, "null", "null", location
    except Exception as e:
        return 0, "null", "null", f"{location} (error: {e})"


def build_report_html(origin_label: str, dest_label: str, vehicle: str, path: dict, outfile: str = "report.html") -> str:
    """Creates the map + directions report (no API snapshot)."""
    km = float(path.get("distance", 0.0)) / 1000.0
    miles = km_to_miles(km)
    duration_ms = int(path.get("time", 0))
    duration_str = format_duration_ms(duration_ms)
    steps = path.get("instructions", [])
    coords = path.get("points", {}).get("coordinates", [])

    latlon = [[c[1], c[0]] for c in coords]
    rows = "".join(
        f"<tr><td>{i+1}</td><td>{s.get('text','')}</td><td>{(float(s.get('distance',0))/1000):.1f} km</td></tr>"
        for i, s in enumerate(steps)
    )

    html = f"""<!doctype html>
<html lang='en'>
<head>
<meta charset='utf-8'>
<title>Route Report</title>
<meta name='viewport' content='width=device-width, initial-scale=1'>
<link rel='stylesheet' href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css' crossorigin=''/>
<script src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js' crossorigin=''></script>
<style>
body {{font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;background:#fafafa;margin:0;padding:0}}
header {{background:#0b6;color:white;padding:16px 24px}}
.wrap {{padding:16px 24px}}
.grid {{display:grid;grid-template-columns:2fr 1fr;gap:16px}}
.card {{background:white;border-radius:12px;padding:12px;box-shadow:0 2px 8px rgba(0,0,0,0.1)}}
#map {{height:520px;width:100%;border-radius:10px}}
table {{width:100%;border-collapse:collapse;font-size:14px}}
th,td {{padding:8px 6px;border-bottom:1px solid #eee;text-align:left}}
th {{background:#f6f6f6}}
.kpi {{display:flex;gap:12px;flex-wrap:wrap}}
.pill {{background:#eef9f1;border:1px solid #cdebd7;padding:8px 10px;border-radius:999px;font-weight:600}}
</style>
</head>
<body>
<header>
<h1>Route: {origin_label} → {dest_label}</h1>
<div>Vehicle: <b>{vehicle}</b></div>
</header>
<div class='wrap'>
<div class='grid'>
<div class='card'><div id='map'></div></div>
<div class='card'>
<h3>Summary</h3>
<div class='kpi'>
<div class='pill'>Distance: {miles:.1f} miles / {km:.1f} km</div>
<div class='pill'>Duration: {duration_str}</div>
</div>
</div></div>
<div class='card' style='margin-top:16px'>
<h3>Turn-by-turn</h3>
<table><thead><tr><th>#</th><th>Instruction</th><th>Distance</th></tr></thead>
<tbody>{rows}</tbody></table></div></div>
<script>
const latlon = {json.dumps(latlon)};
const map = L.map('map').setView(latlon[Math.floor(latlon.length/2)], 12);
L.tileLayer('https://{{s}}.tile.openstreetmap.org/{{z}}/{{x}}/{{y}}.png', {{
  maxZoom:19, attribution:'&copy; OpenStreetMap contributors'
}}).addTo(map);
const line = L.polyline(latlon, {{color:'#0078ff', weight:5}}).addTo(map);
L.marker(latlon[0]).addTo(map).bindTooltip("Start");
L.marker(latlon[latlon.length-1]).addTo(map).bindTooltip("End");
map.fitBounds(line.getBounds(), {{padding:[20,20]}});
</script>
</body></html>"""

    with open(outfile, "w", encoding="utf-8") as f:
        f.write(html)
    return outfile


# --- Logic ---
def run_route(origin, dest, vehicle, status_var):
    api_key = get_api_key()
    status_var.set("Geocoding...")
    s1, lat1, lng1, label1 = geocode(origin, api_key)
    s2, lat2, lng2, label2 = geocode(dest, api_key)

    if not (s1 == 200 and s2 == 200):
        messagebox.showerror("Error", "Geocoding failed. Try clearer names.")
        status_var.set("Ready")
        return

    base_params = {
        "key": api_key,
        "vehicle": vehicle,
        "points_encoded": "false",
        "instructions": "true",
    }
    op = f"&point={lat1}%2C{lng1}"
    dp = f"&point={lat2}%2C{lng2}"
    url = ROUTE_URL + urllib.parse.urlencode(base_params) + op + dp

    status_var.set("Getting route...")
    try:
        r = requests.get(url, timeout=30)
        data = r.json()
    except Exception as e:
        messagebox.showerror("Error", f"Route request failed: {e}")
        status_var.set("Ready")
        return

    if r.status_code != 200 or "paths" not in data:
        messagebox.showerror("Error", f"Routing failed: {data.get('message','Unknown error')}")
        status_var.set("Ready")
        return

    path = data["paths"][0]
    status_var.set("Creating report...")
    report = build_report_html(label1, label2, vehicle, path, "report.html")
    abs_path = os.path.abspath(report)
    webbrowser.open(f"file://{abs_path}")
    status_var.set("Done")


# --- GUI ---
def main():
    root = tk.Tk()
    root.title("Graphhopper Route → Report")
    root.resizable(False, False)

    frm = ttk.Frame(root, padding=10)
    frm.grid(row=0, column=0, sticky="nsew")

    ttk.Label(frm, text="Origin:").grid(row=0, column=0, sticky="w", pady=4)
    e_origin = ttk.Entry(frm, width=50)
    e_origin.grid(row=0, column=1, pady=4)

    ttk.Label(frm, text="Destination:").grid(row=1, column=0, sticky="w", pady=4)
    e_dest = ttk.Entry(frm, width=50)
    e_dest.grid(row=1, column=1, pady=4)

    ttk.Label(frm, text="Vehicle:").grid(row=2, column=0, sticky="w", pady=4)
    vehicle_var = tk.StringVar(value="car")
    cmb = ttk.Combobox(frm, textvariable=vehicle_var, values=["car", "bike", "foot"], state="readonly", width=10)
    cmb.grid(row=2, column=1, sticky="w", pady=4)

    status_var = tk.StringVar(value="Ready")
    ttk.Label(frm, textvariable=status_var, foreground="#0b6").grid(row=3, column=0, columnspan=2, pady=4, sticky="w")

    def on_generate():
        o, d = e_origin.get().strip(), e_dest.get().strip()
        v = vehicle_var.get()
        if not o or not d:
            messagebox.showwarning("Missing Input", "Please fill in both Origin and Destination.")
            return
        run_route(o, d, v, status_var)

    ttk.Button(frm, text="Generate Report", command=on_generate).grid(row=4, column=0, columnspan=2, sticky="ew", pady=8)
    e_origin.focus()
    root.mainloop()


if __name__ == "__main__":
    main()
